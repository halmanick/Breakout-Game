Fill this in before the final project deadline. Someone who has _no familiarity_ with your project should be able to read this and understand:
* what your project does
* how to set it up and run it
